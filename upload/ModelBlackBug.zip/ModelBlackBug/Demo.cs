﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;

namespace ModelBlackBug
{
    class Demo
    {
        // Avoid method inlining
        [MethodImpl(MethodImplOptions.NoInlining)]
        static public void Run()
        {
            using (Game1 game = new Game1())
            {
                game.Run();
            }            
        }


    }
}
