// MyXnaNativeLib.h

#pragma once

using namespace System;

namespace MyXnaNativeLib {

	public ref class Class1
	{
		// TODO: Add your methods for this class here.
	};
}
