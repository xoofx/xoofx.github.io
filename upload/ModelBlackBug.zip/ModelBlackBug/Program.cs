using System;
using System.Windows.Forms;

namespace ModelBlackBug
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            try
            {
                Demo.Run();
            } catch (Exception ex)
            {
                string msg = String.Format("An error occured. Exception {0} StackTrace {1} InnerException : {2}", ex.Message, ex.StackTrace, ex.InnerException);
                MessageBox.Show(msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error,
                                MessageBoxDefaultButton.Button1);
            }
        }
    }
}

