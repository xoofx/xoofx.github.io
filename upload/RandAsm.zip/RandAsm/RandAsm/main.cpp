// RandAsm
// Testing suite for generating random floating point numbers in the range [-1,1)
// Check RandAsm.asm to activate the correct function

#include <windows.h>
#include <stdio.h>
#include <math.h>
extern "C" float Rand();

#define COUNT 1000000000
#define NB_BUCKET 100 
#define NUMBER_BY_BUCKET (COUNT/NB_BUCKET)
int counts[NB_BUCKET+1];
float total;

inline long floorSSE(double x) {
    __asm CVTTSD2SI eax,x
}

// #define USE_C_RAND
#ifdef USE_C_RAND
float Rand() {
	return ((float)rand()/RAND_MAX) * 2.0 - 1.0f;
}
#endif

const unsigned int xxx = 0x80000001;
double yyy;
unsigned int zzz;

#ifdef _DEBUG
int main()
#else
int mymain()
#endif
{
	long int start = GetTickCount();

	_asm {
		
		fild xxx
		fst qword ptr [yyy]
		fistp dword ptr [zzz]
	};

	for(int i = 0; i < COUNT; i++) {
		double temp = Rand();
		double bucketIndex = temp * (NB_BUCKET/2) + (NB_BUCKET/2);
		int countIndex = floorSSE(bucketIndex);
		if ( countIndex < 0 || countIndex >= NB_BUCKET ) {
			printf("[%d] invalid bucket: %d %2.6f\n",i, countIndex, bucketIndex);
			if ( countIndex == NB_BUCKET ) {
				countIndex = NB_BUCKET - 1;
			}
		}
		counts[countIndex]++;
	}

	
	long int end = GetTickCount();


	float totalError = 0.0f;
	for(int i = 0; i < NB_BUCKET; i++) {
		float error = (float)NUMBER_BY_BUCKET- counts[i];
		float errorSq = error * error / (float)NUMBER_BY_BUCKET;
		totalError += errorSq;
		printf("[%1.2f-%1.2f[ = %d = (error: %1.7f)\n",((float)i/NB_BUCKET), ((float)i/NB_BUCKET) + (float)1/NB_BUCKET, counts[i], errorSq);
	}
	printf("Time %dms Total error: %1.7f\n",end-start, totalError);

	return 0;
}

