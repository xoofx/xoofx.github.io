// Copyright (c) 2010-2011 SharpDX - Alexandre Mutel
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
#include <Windows.h>
#include <stdio.h>
#include <D3D11.h>
#include <D3D11Shader.h>
#include <D3Dcompiler.h>
#include <dxerr.h>
#include <stdlib.h>

#define DXHR(result) AssertDirectX(result, #result, __FILE__,__LINE__);

void AssertDirectX(HRESULT result, const char* name, const char* file, DWORD line) {
	HRESULT hr_Val = result; 
	if (FAILED(hr_Val)) { 
		size_t size; 
		wchar_t msg[1024]; 
		mbstowcs_s(&size, msg, 512, name, 1024); 
		// Use DXTraceW instead of DXTraceA (bug?)
		DXTraceW(__FILE__,__LINE__, hr_Val, msg, true);
	}
}

double ClockGetTime()
{
	static bool isInitialized;
	static double timerFreq;
	static unsigned __int64 tmp;
	if ( !isInitialized ) {
		isInitialized = true;
		QueryPerformanceFrequency((LARGE_INTEGER*)&tmp);
		timerFreq = 1.0/(double)tmp;
	}
	QueryPerformanceCounter((LARGE_INTEGER*)&tmp);	
	return ((double)tmp) * timerFreq;
}

int main(int argc, char* argv[])
{
	const int SCREENX = 800;
	const int SCREENY = 600;
	const char* SHADER_FILENAME = "Simple.fx";
    const int nbTests = 100000;
    const int FLUSH_LIMIT = 100;
    const int nbEffects = 10;
	static int VERTEX_STRIDE = 32;

	HWND windowHandle = CreateWindow("static",0, WS_EX_TOPMOST|WS_POPUP|WS_VISIBLE,0,0,SCREENX,SCREENY,0,0,0,0);

	static DXGI_SWAP_CHAIN_DESC swapChainDesc;

    swapChainDesc.BufferCount = 1;
	swapChainDesc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	swapChainDesc.BufferDesc.Width = SCREENX;
	swapChainDesc.BufferDesc.Height = SCREENY;
	swapChainDesc.BufferDesc.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;
	swapChainDesc.BufferDesc.RefreshRate.Numerator = 60;
	swapChainDesc.BufferDesc.RefreshRate.Denominator = 1;
	swapChainDesc.BufferDesc.ScanlineOrdering = DXGI_MODE_SCANLINE_ORDER_UNSPECIFIED;
	swapChainDesc.SampleDesc.Count = 1;
	swapChainDesc.SampleDesc.Quality= 0;
	swapChainDesc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
	swapChainDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	swapChainDesc.Windowed = 1;
	swapChainDesc.OutputWindow = windowHandle;

	IDXGISwapChain* swapChain;
	ID3D11Device* device;
	ID3D11DeviceContext* context;
	D3D_FEATURE_LEVEL featureLevel;

	DXHR(D3D11CreateDeviceAndSwapChain(0,
		D3D_DRIVER_TYPE_HARDWARE,
		0,
		0,
		0,
		0,
		D3D11_SDK_VERSION,
		&swapChainDesc,
		&swapChain,
		&device,
		&featureLevel,
		&context));

	ID3D11Texture2D* backBuffer;	
	DXHR(swapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&backBuffer));

	ID3D11RenderTargetView* renderView; 
	DXHR(device->CreateRenderTargetView(backBuffer, 0, &renderView));

    ID3D11VertexShader* vertexShaders[nbEffects];
    ID3D11PixelShader* pixelShaders[nbEffects];

    ID3DBlob* vertexShaderSignature = 0;

	static char tempSimpleFx[65536];
	FILE* pFile = fopen("Simple.fx", "r");
	int sizeSimpleFx = fread(tempSimpleFx, 1, 65535, pFile);
	fclose(pFile);

    for (int i = 0; i < nbEffects; i++)
    {

		ID3DBlob* d3dcompilerErrors;
		ID3DBlob* vertexShaderByteCode;

		DXHR(D3DCompile(tempSimpleFx, sizeSimpleFx, SHADER_FILENAME, 0, 0, "SimpleVS", "vs_4_0", 0, 0, &vertexShaderByteCode, &d3dcompilerErrors));
        if (vertexShaderSignature == 0)
            DXHR(D3DGetInputSignatureBlob(vertexShaderByteCode->GetBufferPointer(), vertexShaderByteCode->GetBufferSize(), &vertexShaderSignature));

		ID3DBlob* pixelShaderByteCode;
		DXHR(D3DCompile(tempSimpleFx, sizeSimpleFx, SHADER_FILENAME, 0, 0, "SimplePS", "ps_4_0", 0, 0, &pixelShaderByteCode, &d3dcompilerErrors));

		DXHR(device->CreateVertexShader(vertexShaderByteCode->GetBufferPointer(), vertexShaderByteCode->GetBufferSize(), 0, &vertexShaders[i]));
		DXHR(device->CreatePixelShader(pixelShaderByteCode->GetBufferPointer(), pixelShaderByteCode->GetBufferSize(), 0, &pixelShaders[i]));
    }

	static D3D11_INPUT_ELEMENT_DESC layoutDesc[] = {	
	{ "POSITION",	0, DXGI_FORMAT_R32G32B32A32_FLOAT,  0,  0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	{ "COLOR",		0, DXGI_FORMAT_R32G32B32A32_FLOAT,  0, 16, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	};

	ID3D11InputLayout* layout;
	DXHR(device->CreateInputLayout(layoutDesc, 2, vertexShaderSignature->GetBufferPointer(), vertexShaderSignature->GetBufferSize(), &layout));

	static float stream[] = {
        0.0f,  0.5f, 0.5f, 1.0f,	1.0f, 0.0f, 0.0f, 1.0f,
        0.5f, -0.5f, 0.5f, 1.0f,	0.0f, 1.0f, 0.0f, 1.0f,
       -0.5f, -0.5f, 0.5f, 1.0f,	0.0f, 0.0f, 1.0f, 1.0f
	};


	D3D11_BUFFER_DESC verticeBufferDesc;
	verticeBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	verticeBufferDesc.CPUAccessFlags = 0;
	verticeBufferDesc.MiscFlags = 0;
	verticeBufferDesc.ByteWidth = VERTEX_STRIDE * 3;
	verticeBufferDesc.Usage = D3D11_USAGE_DEFAULT;
	verticeBufferDesc.StructureByteStride = 0;

	ID3D11Buffer* vertices;
	DXHR(device->CreateBuffer(&verticeBufferDesc, 0, &vertices));

	D3D11_VIEWPORT viewPort = { 0, 0, SCREENX, SCREENY, 0.0f, 1.0f };
	float blackColor[4] = {1.0f, 0.0f, 0.0f, 0.0f};

	double totalTime = 0;

	double start = ClockGetTime();

	char* arch = sizeof(void*)==4?"32bit":"64bit";

	for (int j = 0; j < (nbTests+1); j++)
	{
		for (int i = 0; i < nbEffects; i++)
		{
			context->IASetInputLayout(layout);
			context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
			
			static UINT pOffset;
			context->IASetVertexBuffers(0, 1, &vertices, (UINT*)&VERTEX_STRIDE, &pOffset);
			context->VSSetShader(vertexShaders[i], 0, 0);
			context->RSSetViewports(1, &viewPort);
			context->PSSetShader(pixelShaders[i], 0, 0);
			context->OMSetRenderTargets(1, &renderView, 0);
			context->ClearRenderTargetView(renderView, blackColor);
			context->Draw(3, 0);
		}

		if (j > 0 && (j % FLUSH_LIMIT) == 0 ) {
			totalTime += ClockGetTime() - start;
			printf("Native (%s) - Time per pass %f ms - %3d%%\r", arch, (double)(totalTime)*1000.0/ (j * nbEffects), j*100/nbTests);
			context->Flush();
			start = ClockGetTime();
		}
	}

	return 0;
}

