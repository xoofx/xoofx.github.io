// Copyright (c) 2010-2011 SharpDX - Alexandre Mutel
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

using System;
using System.Diagnostics;
using System.Windows.Forms;
using Microsoft.WindowsAPICodePack.DirectX.Direct3D11;
using Microsoft.WindowsAPICodePack.DirectX.Graphics;
using Size = System.Drawing.Size;

namespace Sharp3DBench
{
    /// <summary>
    ///   SharpDX port of SharpDX-MiniTri Direct3D 11 Sample
    /// </summary>
    internal static class ProgramWindowsPackDirectX
    {
        [STAThread]
        public static void Run()
        {
            var form = new Form { ClientSize = new Size(800, 600) };

            // SwapChain description
            var desc = new SwapChainDescription()
            {
                BufferCount = 1,
                BufferDescription = new ModeDescription() { Width =  (uint)form.ClientSize.Width, Height = (uint)form.ClientSize.Height, Format = Format.R8G8B8A8UNorm, RefreshRate =  
                                        new Rational(60, 1), Scaling = ModeScaling.Unspecified, ScanlineOrdering = ModeScanlineOrder.Unspecified},
                Windowed = true,
                OutputWindowHandle = form.Handle,
                SampleDescription = new SampleDescription(1, 0),
                SwapEffect = SwapEffect.Discard,
                BufferUsage= UsageOptions.RenderTargetOutput,
                Options = SwapChainOptions.None
            };

            // Create Device and SwapChain
            D3DDevice device;            
            SwapChain swapChain;
            device = D3DDevice.CreateDeviceAndSwapChain(null, DriverType.Hardware, "", CreateDeviceOptions.None, null, desc);
            swapChain = device.SwapChain;
            var context = device.ImmediateContext;

            // New RenderTargetView from the backbuffer

            Texture2D backBuffer = swapChain.GetBuffer<Texture2D>(0);
            var renderView = device.CreateRenderTargetView(backBuffer);


            var vertexShaders = new VertexShader[CommonBench.NbEffects];
            var pixelShaders = new PixelShader[CommonBench.NbEffects];
            SlimDX.D3DCompiler.ShaderSignature vertexShaderSignature = null;

            for (int i = 0; i < CommonBench.NbEffects; i++)
            {
                var vertexShaderByteCode = SlimDX.D3DCompiler.ShaderBytecode.CompileFromFile("Simple.fx", "SimpleVS", "vs_4_0", SlimDX.D3DCompiler.ShaderFlags.None,
                                                                          SlimDX.D3DCompiler.EffectFlags.None);
                if (vertexShaderSignature == null)
                    vertexShaderSignature = SlimDX.D3DCompiler.ShaderSignature.GetInputSignature(vertexShaderByteCode);

                var pixelShaderByteCode = SlimDX.D3DCompiler.ShaderBytecode.CompileFromFile("Simple.fx", "SimplePS", "ps_4_0", SlimDX.D3DCompiler.ShaderFlags.None,
                                                                         SlimDX.D3DCompiler.EffectFlags.None);

                vertexShaders[i] = device.CreateVertexShader(vertexShaderByteCode.Data.DataPointer, (uint)vertexShaderByteCode.Data.Length);
                pixelShaders[i] = device.CreatePixelShader(pixelShaderByteCode.Data.DataPointer, (uint)pixelShaderByteCode.Data.Length);
            }

            // Layout from VertexShader input signature
            var layout = device.CreateInputLayout(new[] { 
                new InputElementDescription() { SemanticName = "POSITION", SemanticIndex = 0, Format  = Format.R32G32B32A32Float, AlignedByteOffset = 0, InputSlot = 0, InputSlotClass = 0, InstanceDataStepRate = 0 },
                new InputElementDescription() { SemanticName = "COLOR", SemanticIndex = 0, Format  = Format.R32G32B32A32Float, AlignedByteOffset = 16, InputSlot = 0, InputSlotClass = 0, InstanceDataStepRate = 0 } }, vertexShaderSignature.Data.DataPointer, (uint)vertexShaderSignature.Data.Length);

            // Write vertex data to a datastream
            var stream = new SlimDX.DataStream(32 * 3, true, true);
            stream.WriteRange(new[]
                                  {
                                      new SlimDX.Vector4(0.0f, 0.5f, 0.5f, 1.0f), new SlimDX.Vector4(1.0f, 0.0f, 0.0f, 1.0f),
                                      new SlimDX.Vector4(0.5f, -0.5f, 0.5f, 1.0f), new SlimDX.Vector4(0.0f, 1.0f, 0.0f, 1.0f),
                                      new SlimDX.Vector4(-0.5f, -0.5f, 0.5f, 1.0f), new SlimDX.Vector4(0.0f, 0.0f, 1.0f, 1.0f)
                                  });
            stream.Position = 0;


            // Instantiate Vertex buiffer from vertex data
            var vertices = device.CreateBuffer(new BufferDescription()
            {
                BindingOptions = BindingOptions.VertexBuffer,
                CpuAccessOptions = CpuAccessOptions.None,
                MiscellaneousResourceOptions = MiscellaneousResourceOptions.None,
                ByteWidth = 32 * 3,
                Usage = Usage.Default,
                StructureByteStride = 0
            }, new SubresourceData() { SystemMemory = stream.DataPointer, SystemMemoryPitch = (uint)(32 * 3), SystemMemorySlicePitch = 0 } );
            stream.Dispose();

            var vertexBufferBindings = new VertexBuffer[CommonBench.NbEffects];
            for (int i = 0; i < CommonBench.NbEffects; i++)
                vertexBufferBindings[i] = new VertexBuffer(vertices, 32, 0);

            var viewPort = new Viewport() { TopLeftX = 0, TopLeftY = 0, Width = form.ClientSize.Width, Height = form.ClientSize.Height, MinDepth = 0.0f, MaxDepth = 1.0f };
            var blackColor = new ColorRgba(1.0f, 0.0f, 0.0f, 0.0f);

            var renderViewOM = new OutputMergerRenderTargets(new [] { renderView});

            var clock = new Stopwatch();
            clock.Start();
            for (int j = 0; j < (CommonBench.NbTests + 1); j++)
            {
                for (int i = 0; i < CommonBench.NbEffects; i++)
                {
                    context.IA.InputLayout = layout;
                    context.IA.PrimitiveTopology = PrimitiveTopology.TriangleList;
                    context.IA.SetVertexBuffers(0, new [] {vertexBufferBindings[i]});
                    context.VS.SetShader(vertexShaders[i], null);
                    context.RS.Viewports = new [] {viewPort};
                    context.PS.SetShader(pixelShaders[i], null);
                    context.OM.RenderTargets = renderViewOM;
                    context.ClearRenderTargetView(renderView, blackColor);
                    context.Draw(3, 0);
                }
                if (j > 0 && (j % CommonBench.FlushLimit) == 0)
                {
                    clock.Stop();
                    context.Flush();
                    clock.Start();
                }
            }
            // context.Flush();
            clock.Stop();
            Console.WriteLine("Time per pass {0}ms", (double)clock.ElapsedMilliseconds / (CommonBench.NbTests * CommonBench.NbEffects));

            vertices.Dispose();
            layout.Dispose();
            renderView.Dispose();
            backBuffer.Dispose();
            context.ClearState();
            context.Flush();
            device.Dispose();
            context.Dispose();
            swapChain.Dispose();
        }
    }
}