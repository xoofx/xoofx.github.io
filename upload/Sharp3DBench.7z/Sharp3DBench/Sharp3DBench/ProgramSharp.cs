﻿// Copyright (c) 2010-2011 SharpDX - Alexandre Mutel
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

using System;
using System.Diagnostics;
using System.Windows.Forms;
using Size = System.Drawing.Size;
#if SHARPDX
using SharpDX;
using SharpDX.D3DCompiler;
using SharpDX.Direct3D;
using SharpDX.Direct3D11;
using SharpDX.DXGI;
using Buffer = SharpDX.Direct3D11.Buffer;
using Device = SharpDX.Direct3D11.Device;
#else
using SlimDX;
using SlimDX.D3DCompiler;
using SlimDX.Direct3D11;
using SlimDX.DXGI;
using Buffer = SlimDX.Direct3D11.Buffer;
using Device = SlimDX.Direct3D11.Device;
#endif

namespace Sharp3DBench
{
    /// <summary>
    ///   SharpDX port of SharpDX-MiniTri Direct3D 11 Sample
    /// </summary>
    internal static class ProgramSharp
    {
        [STAThread]
        public static void Run()
        {
            string arch = IntPtr.Size == 4 ? "32bit" : "64bit";

            // Compile Vertex and Pixel shaders
            string programName;
#if SHARPDX
            programName = "SharpDX";
#else
            programName = "SlimDX";
#endif

            var form = new Form {ClientSize = new Size(800, 600)};

            // SwapChain description
            var desc = new SwapChainDescription()
                           {
                               BufferCount = 1,
                               ModeDescription= 
                                   new ModeDescription(form.ClientSize.Width, form.ClientSize.Height,
                                                       new Rational(60, 1), Format.R8G8B8A8_UNorm),
                               IsWindowed = true,
                               OutputHandle = form.Handle,
                               SampleDescription = new SampleDescription(1, 0),
                               SwapEffect = SwapEffect.Discard,
                               Usage = Usage.RenderTargetOutput
                           };

            // Create Device and SwapChain
            Device device;
            SwapChain swapChain;
            Device.CreateWithSwapChain(DriverType.Hardware, DeviceCreationFlags.None, desc, out device, out swapChain);
            var context = device.ImmediateContext;

            // New RenderTargetView from the backbuffer
            Texture2D backBuffer = Texture2D.FromSwapChain<Texture2D>(swapChain, 0);
            var renderView = new RenderTargetView(device, backBuffer);

            var vertexShaders = new VertexShader[CommonBench.NbEffects];
            var pixelShaders = new PixelShader[CommonBench.NbEffects];

            ShaderSignature vertexShaderSignature = null;

            for (int i = 0; i < CommonBench.NbEffects; i++)
            {
                var vertexShaderByteCode = ShaderBytecode.CompileFromFile("Simple.fx", "SimpleVS", "vs_4_0", ShaderFlags.None,
                                                                          EffectFlags.None);
                if (vertexShaderSignature == null)
                    vertexShaderSignature = ShaderSignature.GetInputSignature(vertexShaderByteCode);

                var pixelShaderByteCode = ShaderBytecode.CompileFromFile("Simple.fx", "SimplePS", "ps_4_0", ShaderFlags.None,
                                                                         EffectFlags.None);

                vertexShaders[i] = new VertexShader(device, vertexShaderByteCode);
                pixelShaders[i] = new PixelShader(device, pixelShaderByteCode);
            }

            // Layout from VertexShader input signature
            var layout = new InputLayout(device, vertexShaderSignature, new[] { 
                new InputElement("POSITION",0,Format.R32G32B32A32_Float,0,0),
                new InputElement("COLOR",0,Format.R32G32B32A32_Float,16,0)
            });

            // Write vertex data to a datastream
            var stream = new DataStream(32*3, true, true);
            stream.WriteRange(new[]
                                  {
                                      new Vector4(0.0f, 0.5f, 0.5f, 1.0f), new Vector4(1.0f, 0.0f, 0.0f, 1.0f),
                                      new Vector4(0.5f, -0.5f, 0.5f, 1.0f), new Vector4(0.0f, 1.0f, 0.0f, 1.0f),
                                      new Vector4(-0.5f, -0.5f, 0.5f, 1.0f), new Vector4(0.0f, 0.0f, 1.0f, 1.0f)
                                  });
            stream.Position = 0;

            // Instantiate Vertex buiffer from vertex data
            var vertices = new Buffer(device, stream, new BufferDescription()
                                                          {
                                                              BindFlags = BindFlags.VertexBuffer,
                                                              CpuAccessFlags = CpuAccessFlags.None,
                                                              OptionFlags = ResourceOptionFlags.None,
                                                              SizeInBytes = 32*3,
                                                              Usage = ResourceUsage.Default,
                                                              StructureByteStride = 0
                                                          });
            stream.Dispose();

            var vertexBufferBindings = new VertexBufferBinding[CommonBench.NbEffects];
            for(int i = 0; i < CommonBench.NbEffects; i++)
                vertexBufferBindings[i] = new VertexBufferBinding(vertices, 32, 0);

            var viewPort = new Viewport(0, 0, form.ClientSize.Width, form.ClientSize.Height, 0.0f, 1.0f);
            var blackColor = new Color4(1.0f, 0.0f, 0.0f, 0.0f);

            var clock = new Stopwatch();
            clock.Start();

            for (int j = 0; j < (CommonBench.NbTests + 1); j++)
            {
                for (int i = 0; i < CommonBench.NbEffects; i++)
                {
#if SHARPDX
                    context.InputAssembler.SetInputLayout(layout);
                    context.InputAssembler.SetPrimitiveTopology(PrimitiveTopology.TriangleList);
#else
                    context.InputAssembler.InputLayout = layout;
                    context.InputAssembler.PrimitiveTopology = PrimitiveTopology.TriangleList;
#endif
                    context.InputAssembler.SetVertexBuffers(0, vertexBufferBindings[i]);
                    context.VertexShader.Set(vertexShaders[i]);
                    context.Rasterizer.SetViewports(viewPort);
                    context.PixelShader.Set(pixelShaders[i]);
                    context.OutputMerger.SetTargets(renderView);
                    context.ClearRenderTargetView(renderView, blackColor);
                    context.Draw(3, 0);
                }
                if (j > 0 && (j % CommonBench.FlushLimit) == 0)
                {
                    clock.Stop();
                    Console.Write("{0} ({3}) - Time per pass {1:0.000000}ms - {2:000}%\r", programName, (double)clock.ElapsedMilliseconds / (j * CommonBench.NbEffects), j * 100 / (CommonBench.NbTests), arch);
                    context.Flush();
                    clock.Start();
                }
            }
            // context.Flush();
            clock.Stop();
            //Console.WriteLine("{0} - Time per pass {1}ms", programName, (double)clock.ElapsedMilliseconds / (CommonBench.NbTests * CommonBench.NbEffects));

            vertices.Dispose();
            layout.Dispose();
            renderView.Dispose();
            backBuffer.Dispose();
            context.ClearState();
            context.Flush();
            device.Dispose();
            context.Dispose();
            swapChain.Dispose();
        }
    }
}