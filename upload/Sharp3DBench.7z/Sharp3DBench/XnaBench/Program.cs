﻿// Copyright (c) 2010-2011 SharpDX - Alexandre Mutel
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Sharp3DBench;
using Color = Microsoft.Xna.Framework.Color;

namespace XnaBench
{
    class Program
    {
        static void Main(string[] args)
        {
            string arch = IntPtr.Size == 4 ? "32bit" : "64bit";

            // Compile Vertex and Pixel shaders
            string programName = "XNA";

            var form = new Form {ClientSize = new Size(800, 600)};


            var presentationParameters = new PresentationParameters()
                                                                {
                                                                    BackBufferWidth = form.ClientSize.Width,
                                                                    BackBufferHeight = form.ClientSize.Height,
                                                                    BackBufferFormat = SurfaceFormat.Color,
                                                                    DepthStencilFormat = DepthFormat.None,
                                                                    DeviceWindowHandle = form.Handle,
                                                                    DisplayOrientation = DisplayOrientation.Default,
                                                                    IsFullScreen = false,
                                                                    MultiSampleCount = 1,
                                                                    PresentationInterval = PresentInterval.Immediate,
                                                                    RenderTargetUsage =RenderTargetUsage.PreserveContents
                                                                };


            var device = new GraphicsDevice(GraphicsAdapter.DefaultAdapter, GraphicsProfile.HiDef, presentationParameters);

            var vertices = new VertexPositionColor[3];

            vertices[0].Position = new Vector3(-0.5f, -0.5f, 0f);
            vertices[0].Color = Color.Red;
            vertices[1].Position = new Vector3(0, 0.5f, 0f);
            vertices[1].Color = Color.Green;
            vertices[2].Position = new Vector3(0.5f, -0.5f, 0f);
            vertices[2].Color = Color.Yellow;

            var vertexBufferBindings = new VertexBuffer[CommonBench.NbEffects];
            for (int i = 0; i < CommonBench.NbEffects; i++)
            {
                vertexBufferBindings[i] = new VertexBuffer(device, typeof (VertexPositionColor), 3, BufferUsage.None);
                vertexBufferBindings[i].SetData(vertices);
            }

            var effects = new Effect[CommonBench.NbEffects];
            for (int i = 0; i < CommonBench.NbEffects; i++)
                effects[i] = new BasicEffect(device);

            var viewPort = new Viewport(0, 0, form.ClientSize.Width, form.ClientSize.Height);
            
            var clock = new Stopwatch();
            clock.Start();
            
            for (int j = 0; j < (CommonBench.NbTests + 1); j++)
            {
                for (int i = 0; i < CommonBench.NbEffects; i++)
                {
                    device.SetVertexBuffer(vertexBufferBindings[i]);
                    device.Viewport = viewPort;
                    device.SetRenderTarget(null);
                    device.Clear(Color.Black);
                    effects[i].Techniques[0].Passes[0].Apply();
                    device.DrawPrimitives(PrimitiveType.TriangleList, 0, 1);
                }
                if (j > 0 && (j % CommonBench.FlushLimit) == 0)
                {
                    clock.Stop();
                    Console.Write("{0} ({3}) - Time per pass {1:0.000000}ms - {2:000}%\r", programName, (double)clock.ElapsedMilliseconds / (j * CommonBench.NbEffects), j * 100 / (CommonBench.NbTests), arch);
                    device.Present();
                    clock.Start();
                }
            }
            // context.Flush();
            clock.Stop();
        }
    }
}
