using System;
using System.Drawing;

namespace SphereTracing2DApp
{
    public class Box : GeometryBase
    {
        private SizeF _size;
        public Box(PointF center, Color color, SizeF size) : base(center, color)
        {
            _size = size;
        }

        public SizeF Size
        {
            get { return _size; }
            set { _size = value; }
        }

        #region Overrides of GeometryBase

        public override float Distance(PointF xy)
        {
            return Math.Max(Math.Abs(xy.X - Center.X) - Size.Width, Math.Abs(xy.Y - Center.Y) - Size.Height);
        }

        public override void Draw(Graphics graphics, Rectangle container)
        {
            Point centerSc = Position(container, new PointF(Center.X, Center.Y));
            Size sizeSc = new Size(Width(container, Size.Width), Height(container,Size.Height));
            graphics.FillRectangle(new SolidBrush(Color), centerSc.X-sizeSc.Width/2, centerSc.Y - sizeSc.Height/2, sizeSc.Width, sizeSc.Height);
        }

        #endregion
    }
}