﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace SphereTracing2DApp
{
    public partial class GeometryContainerUI : UserControl
    {
        private List<GeometryBase> _geometryList = new List<GeometryBase>();
        public GeometryContainerUI()
        {
            InitializeComponent();
            SetStyle(ControlStyles.DoubleBuffer|ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint, true);
        }

        public void AddGeometry(GeometryBase geometry)
        {
            _geometryList.Add(geometry);
            Refresh();
        }

        private PointF _rayPosition;
        private float _rayAngle;

        public PointF RayPosition
        {
            get { return _rayPosition; }
            set
            {
                _rayPosition = value;
                Refresh();
            }
        }

        public float RayAngle
        {
            get { return _rayAngle; }
            set
            {
                _rayAngle = value;
                Refresh();
            }
        }

        public bool IsPointOutside(PointF point)
        {
            return (point.X < -1 || point.X > 1 || point.Y < -1 || point.Y > 1);
        }


        private bool isMovingRay = false;
        private GeometryBase selectedMovingObject = null;

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if ( IsMouseOnRay(e.Location))
            {
                isMovingRay = true;
            } else
            {
                selectedMovingObject = IsMouseOnObject(e.Location);
            }
        }

        private PointF mousePosition;

        bool IsMouseOnRay(Point location)
        {
            mousePosition = GeometryBase.ScreenPositionToGeometry(ClientRectangle, location);
            return Sphere.Distance(_rayPosition, 0.1f, mousePosition) < 0;
        }

        GeometryBase IsMouseOnObject(Point location)
        {
            mousePosition = GeometryBase.ScreenPositionToGeometry(ClientRectangle, location);

            GeometryBase selectedGeometry = null;
            foreach (GeometryBase geometryBase in _geometryList)
            {
                // Draw the geometry
                if ( geometryBase.Distance(mousePosition) < 0 )
                {
                    selectedGeometry = geometryBase;
                    break;
                }
            }
            return selectedGeometry;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (IsMouseOnRay(e.Location) || IsMouseOnObject(e.Location) != null)
            {
                Cursor = Cursors.SizeAll;
            } else
            {
                Cursor = Cursors.Default;
            }

            PointF selectedPosition;

            if ((isMovingRay || selectedMovingObject != null) && e.Button == MouseButtons.Left)
            {
                mousePosition = GeometryBase.ScreenPositionToGeometry(ClientRectangle, e.Location);
                if (mousePosition.X < -0.98)
                {
                    mousePosition.X = -0.98f;
                } else if (mousePosition.X > 0.98)
                {
                    mousePosition.X = 0.98f;
                } 

                if ( mousePosition.Y < -0.98 ) 
                {
                    mousePosition.Y = -0.98f;
                } else if (mousePosition.Y > 0.98)
                {
                    mousePosition.Y = 0.98f;
                }

                if (selectedMovingObject != null)
                {
                    selectedMovingObject.Center = mousePosition;
                    Refresh();
                }
                else
                {
                    RayPosition = mousePosition;
                }
            }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            isMovingRay = false;
            selectedMovingObject = null;
        }

        protected override void OnPaint(PaintEventArgs e)
        {            
            base.OnPaint(e);

            Point rayPositionSc = GeometryBase.Position(ClientRectangle, _rayPosition);
            SizeF rayDirection = new SizeF((float)Math.Cos(_rayAngle), (float)Math.Sin(_rayAngle));
            Rectangle originRayBox = new Rectangle(rayPositionSc.X - 6, rayPositionSc.Y - 6, 12, 12);

            float minDistance = float.MaxValue;

            // Draw the Raymarching
            PointF currentRay = _rayPosition;
            int numberOfSteps = 0;
            GeometryBase selectedGeometry = null;
            const float MIN_DISTANCE = 0.01f;
            while (_geometryList.Count > 0 && minDistance > MIN_DISTANCE && !IsPointOutside(currentRay))
            {
                // Calculate the min distance from all geometry
                minDistance = float.MaxValue;
                selectedGeometry = null;
                foreach (GeometryBase geometryBase in _geometryList)
                {
                    float newDistance = geometryBase.Distance(currentRay);
                    if ( newDistance < minDistance )
                    {
                        minDistance = newDistance;
                        selectedGeometry = geometryBase;
                    }
                }


                if (minDistance > MIN_DISTANCE)
                {
                    Point currentRaySc = GeometryBase.Position(ClientRectangle, currentRay);
                    int minDistanceX = GeometryBase.Width(ClientRectangle, minDistance/2);
                    int minDistanceY = GeometryBase.Height(ClientRectangle, minDistance/2);

                    // Draw raymarching step distance closest geometry
                    e.Graphics.DrawEllipse(new Pen(Color.White),
                                           new Rectangle(currentRaySc.X - minDistanceX, currentRaySc.Y - minDistanceY,
                                                         minDistanceX*2, minDistanceY*2));


                    rayPositionSc = GeometryBase.Position(ClientRectangle, currentRay);
                    Rectangle rayBox = new Rectangle(rayPositionSc.X - 4, rayPositionSc.Y - 4, 8, 8);

                    // Draw ray step
                    e.Graphics.FillEllipse(new SolidBrush(Color.Green),rayBox);

                    // Draw ray direction to selected Object center
                    e.Graphics.DrawLine(new Pen(Color.DarkGreen, 2), rayPositionSc,
                                        GeometryBase.Position(ClientRectangle, selectedGeometry.Center));


                    // Draw ray direction to intersection or infinity
                    Size rayFullDirectionSc = new Size((int)(rayDirection.Width * minDistanceX), -(int)(rayDirection.Height * minDistanceY));
                    e.Graphics.DrawLine(new Pen(Color.Red, 2), rayPositionSc, Point.Add(rayPositionSc, rayFullDirectionSc));

                    // Raymarching here
                    currentRay = PointF.Add(currentRay,
                                            new SizeF(rayDirection.Width*minDistance, rayDirection.Height*minDistance));
                }
                numberOfSteps++;
            }

            // Draw geometry
            foreach (GeometryBase geometryBase in _geometryList)
            {
                // Draw the geometry
                geometryBase.Draw(e.Graphics, ClientRectangle);
            }

            // Draw center of ray in case it is inside a geometry
            e.Graphics.FillEllipse(new SolidBrush(Color.White), originRayBox);

            // Print number of steps
            string stepsStr = (minDistance < 0.01) ? "" + numberOfSteps : "NoIntersect";

            string geometry = "";
            if ((isMovingRay || selectedMovingObject != null) && MouseButtons == MouseButtons.Left)
            {
                geometry = string.Format("Pos({0:f3},{1:f3}", mousePosition.X, mousePosition.Y);
            }
            e.Graphics.DrawString(string.Format("Steps: {0} Ray Angle {1}° {2}", stepsStr, (int)(RayAngle * 180 / Math.PI), geometry), Font, new SolidBrush(Color.White), 5, 5);
            if (selectedGeometry != null && minDistance < MIN_DISTANCE)
            {
                e.Graphics.FillRectangle(new SolidBrush(selectedGeometry.Color), new Rectangle(5, 20, 100, 10));
            }

            // Draw help
            e.Graphics.DrawString("Move Ray Position or Shapes with the mouse",Font, new SolidBrush(Color.White), 5, ClientRectangle.Height - 20);
        }

        private void GeometryContainerUI_Resize(object sender, EventArgs e)
        {
            Refresh();
        }        
    }
}
