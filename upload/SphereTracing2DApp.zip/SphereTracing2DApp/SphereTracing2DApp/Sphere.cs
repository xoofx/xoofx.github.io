using System;
using System.Drawing;

namespace SphereTracing2DApp
{
    public class Sphere : GeometryBase
    {
        private float _radius;

        public Sphere(PointF center, float radius, Color color) : base(center,color)
        {
            _radius = radius;
        }

        #region Overrides of GeometryBase


        public override float Distance(PointF xy)
        {
            return Distance(Center, _radius, xy);
        }

        public static float Distance(PointF center, float radius, PointF xy)
        {
            return (float)(Math.Sqrt(Math.Pow(xy.X - center.X, 2) + Math.Pow(xy.Y - center.Y, 2)) - radius);
        }

        public override void Draw(Graphics graphics, Rectangle container)
        {
            Point centerGfx = Position(container, Center);
            int rx = Width(container, _radius/2);
            int ry = Height(container, _radius/2);
            graphics.FillEllipse(new SolidBrush(Color), new Rectangle(centerGfx.X - rx, centerGfx.Y - ry, rx*2, ry*2));
        }
        #endregion
    }
}