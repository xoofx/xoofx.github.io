﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SphereTracing2DApp
{
    public partial class SphereTracingForm : Form
    {
        public SphereTracingForm()
        {
            InitializeComponent();

            geometryContainerUI1.RayPosition = new PointF(-0.7f, -0.5f);
            geometryContainerUI1.RayAngle = 37*(float)Math.PI/180;
            geometryContainerUI1.AddGeometry(new Sphere(new PointF(0.5f, -0.25f), 0.2f, Color.Red));
            geometryContainerUI1.AddGeometry(new Sphere(new PointF(0.25f, 0.65f), 0.1f, Color.RosyBrown));
            geometryContainerUI1.AddGeometry(new Sphere(new PointF(0.6f, 0.7f), 0.15f, Color.Yellow));
            geometryContainerUI1.AddGeometry(new Sphere(new PointF(0.8f, 0.05f), 0.1f, Color.Gray));
            geometryContainerUI1.AddGeometry(new Sphere(new PointF(-0.2f, 0.5f), 0.3f, Color.DarkViolet));
            geometryContainerUI1.AddGeometry(new Sphere(new PointF(0.7f, 0.4f), 0.05f, Color.Orange));

            geometryContainerUI1.AddGeometry(new Box(new PointF(0.041f, -0.264f), Color.Blue, new SizeF(0.2f,0.1f)));
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            geometryContainerUI1.RayAngle = -(float)trackBar1.Value*(float)Math.PI/180.0f;
        }
    }
}
