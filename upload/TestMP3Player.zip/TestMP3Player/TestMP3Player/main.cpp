#include "MP3Player.h"

int main(int argc, TCHAR* argv[])
{
	MP3Player player;

	player.OpenFromFile(L"demo.mp3");

	player.Play();

	while (player.GetPosition() < 20) {
		printf("Test music for 20s : %f elapsed\n",player.GetPosition());
		Sleep(1000);
	}

	player.Close();

	return 0;
}

